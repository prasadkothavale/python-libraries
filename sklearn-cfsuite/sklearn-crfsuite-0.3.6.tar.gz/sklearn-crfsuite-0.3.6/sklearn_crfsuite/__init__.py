# -*- coding: utf-8 -*-
from .estimator import CRF
