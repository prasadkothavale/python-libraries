.. _api:

API Reference
=============

CRF
---

.. automodule:: sklearn_crfsuite
    :members:

.. autoclass:: CRF()
    :members:


sklearn_crfsuite.metrics
------------------------

.. automodule:: sklearn_crfsuite.metrics
    :members:
