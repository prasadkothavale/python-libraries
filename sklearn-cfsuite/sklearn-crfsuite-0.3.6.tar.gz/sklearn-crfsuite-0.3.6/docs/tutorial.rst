Tutorial
========

.. note::

    This tutorial is available as an IPython notebook
    `here <https://github.com/TeamHG-Memex/sklearn-crfsuite/tree/master/docs/CoNLL2002.ipynb>`_.

.. include:: CoNLL2002.rst
